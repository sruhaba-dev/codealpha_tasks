/* ===========================================================
   chat.js — FAQ Chatbot frontend logic
   Handles: sending messages, rendering bubbles + confidence
   meter, dark mode toggle, voice input (Web Speech API),
   speech output, chat history restore, suggestion chips.
   =========================================================== */

const chatWindow = document.getElementById("chatWindow");
const emptyState = document.getElementById("emptyState");
const userInput = document.getElementById("userInput");
const sendBtn = document.getElementById("sendBtn");
const micBtn = document.getElementById("micBtn");
const speakToggle = document.getElementById("speakToggle");
const themeToggle = document.getElementById("themeToggle");
const themeIcon = document.getElementById("themeIcon");
const themeLabel = document.getElementById("themeLabel");
const suggestionsBar = document.getElementById("suggestions");

let speakEnabled = false;

/* ---------------- Theme (Dark Mode) ---------------- */
function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  themeIcon.textContent = theme === "dark" ? "☀️" : "🌙";
  themeLabel.textContent = theme === "dark" ? "Light" : "Dark";
}

(function initTheme() {
  const saved = sessionStorage.getItem("rd_theme") ||
    (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  applyTheme(saved);
})();

themeToggle.addEventListener("click", () => {
  const current = document.documentElement.getAttribute("data-theme");
  const next = current === "dark" ? "light" : "dark";
  applyTheme(next);
  sessionStorage.setItem("rd_theme", next);
});

/* ---------------- Helpers ---------------- */
function scrollToBottom() {
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function hideEmptyState() {
  if (emptyState) emptyState.style.display = "none";
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function addUserBubble(text) {
  hideEmptyState();
  const row = document.createElement("div");
  row.className = "msg-row user";
  row.innerHTML = `
    <div class="bubble">${escapeHtml(text)}</div>
    <div class="avatar user">You</div>
  `;
  chatWindow.appendChild(row);
  scrollToBottom();
}

function addBotBubble({ answer, confidence, understood, category }) {
  hideEmptyState();
  const row = document.createElement("div");
  row.className = "msg-row bot";

  const pct = Math.round((confidence || 0) * 100);
  const fillClass = pct < 40 ? "low" : "";

  row.innerHTML = `
    <div class="avatar bot">RD</div>
    <div>
      <div class="bubble ${understood ? "" : "fallback"}">${escapeHtml(answer)}</div>
      <div class="confidence-row">
        ${category ? `<span class="faq-category-tag">${escapeHtml(category)}</span>` : ""}
        <span>match ${pct}%</span>
        <div class="confidence-track"><div class="confidence-fill ${fillClass}" style="width:${pct}%"></div></div>
      </div>
    </div>
  `;
  chatWindow.appendChild(row);
  scrollToBottom();

  if (speakEnabled && "speechSynthesis" in window) {
    const utter = new SpeechSynthesisUtterance(answer);
    utter.rate = 1.0;
    window.speechSynthesis.speak(utter);
  }
}

function addTypingIndicator() {
  const row = document.createElement("div");
  row.className = "msg-row bot";
  row.id = "typingRow";
  row.innerHTML = `
    <div class="avatar bot">RD</div>
    <div class="bubble"><div class="typing-dots"><span></span><span></span><span></span></div></div>
  `;
  chatWindow.appendChild(row);
  scrollToBottom();
}

function removeTypingIndicator() {
  const row = document.getElementById("typingRow");
  if (row) row.remove();
}

/* ---------------- Send message ---------------- */
async function sendMessage() {
  const text = userInput.value.trim();
  if (!text) return;

  addUserBubble(text);
  userInput.value = "";
  addTypingIndicator();

  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text }),
    });
    const data = await res.json();
    removeTypingIndicator();

    if (res.ok) {
      addBotBubble(data);
    } else {
      addBotBubble({ answer: "Something went wrong. Please try again.", confidence: 0, understood: false });
    }
  } catch (err) {
    removeTypingIndicator();
    addBotBubble({ answer: "Network error — please check your connection.", confidence: 0, understood: false });
  }
}

sendBtn.addEventListener("click", sendMessage);
userInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") sendMessage();
});

/* ---------------- Voice Input (Web Speech API) ---------------- */
let recognition = null;
let isRecording = false;

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.lang = "en-US";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  recognition.onstart = () => {
    isRecording = true;
    micBtn.classList.add("recording");
  };
  recognition.onend = () => {
    isRecording = false;
    micBtn.classList.remove("recording");
  };
  recognition.onerror = () => {
    isRecording = false;
    micBtn.classList.remove("recording");
  };
  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    userInput.value = transcript;
    sendMessage();
  };

  micBtn.addEventListener("click", () => {
    if (isRecording) {
      recognition.stop();
    } else {
      recognition.start();
    }
  });
} else {
  micBtn.addEventListener("click", () => {
    alert("Voice input isn't supported in this browser. Try Chrome or Edge.");
  });
}

/* ---------------- Speech Output toggle ---------------- */
speakToggle.addEventListener("click", () => {
  speakEnabled = !speakEnabled;
  speakToggle.classList.toggle("recording", speakEnabled);
  if (!speakEnabled) window.speechSynthesis.cancel();
});

/* ---------------- Suggestion chips (from FAQ list) ---------------- */
async function loadSuggestions() {
  try {
    const res = await fetch("/api/faqs/list");
    const data = await res.json();
    const sample = (data.faqs || []).slice(0, 4);
    suggestionsBar.innerHTML = sample
      .map((f) => `<button class="chip" data-q="${escapeHtml(f.question)}">${escapeHtml(f.question)}</button>`)
      .join("");

    document.querySelectorAll(".chip").forEach((chip) => {
      chip.addEventListener("click", () => {
        userInput.value = chip.dataset.q;
        sendMessage();
      });
    });
  } catch (err) {
    /* fail silently — suggestions are a nice-to-have */
  }
}

/* ---------------- Restore Chat History on load ---------------- */
async function loadHistory() {
  try {
    const res = await fetch("/api/history");
    const data = await res.json();
    if (data.history && data.history.length > 0) {
      hideEmptyState();
      data.history.forEach((item) => {
        addUserBubble(item.user_query);
        addBotBubble({
          answer: item.matched_answer,
          confidence: item.confidence_score,
          understood: !!item.was_understood,
          category: null,
        });
      });
    }
  } catch (err) {
    /* fail silently */
  }
}

loadSuggestions();
loadHistory();
