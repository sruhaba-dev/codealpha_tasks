"""
admin_controller.py
---------------------------------------------------------
Controller (C in MVC) for the Admin Module.
Handles:
  - Admin login / logout
  - FAQ CRUD (Add, Update, Delete, Toggle Active)
  - Dashboard stats (chat counts, unanswered queries)
Every FAQ data change calls matcher.rebuild(...) so the
NLP engine always reflects the latest FAQ dataset.
---------------------------------------------------------
"""

from functools import wraps
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import check_password_hash

from app.models.database import get_db_connection
from app.models.faq_model import FAQModel
from app.models.chat_model import ChatModel
from app.models.nlp_engine import matcher

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


def login_required(view_func):
    """Decorator that protects admin routes behind a login check."""
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if not session.get("is_admin"):
            return redirect(url_for("admin.login"))
        return view_func(*args, **kwargs)
    return wrapped


def refresh_nlp_engine():
    """Reloads the TF-IDF matcher with the latest active FAQs from the DB."""
    faqs = FAQModel.get_all(active_only=True)
    matcher.rebuild(faqs)


@admin_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()

        conn = get_db_connection()
        admin = conn.execute(
            "SELECT * FROM admin_users WHERE username = ?", (username,)
        ).fetchone()
        conn.close()

        if admin and check_password_hash(admin["password_hash"], password):
            session["is_admin"] = True
            session["admin_username"] = username
            return redirect(url_for("admin.dashboard"))

        flash("Invalid username or password.", "error")

    return render_template("admin/login.html")


@admin_bp.route("/logout")
def logout():
    session.pop("is_admin", None)
    session.pop("admin_username", None)
    return redirect(url_for("admin.login"))


@admin_bp.route("/")
@admin_bp.route("/dashboard")
@login_required
def dashboard():
    stats = ChatModel.get_stats()
    faq_count = FAQModel.count()
    unanswered = ChatModel.get_unanswered(limit=10)
    return render_template(
        "admin/dashboard.html",
        stats=stats,
        faq_count=faq_count,
        unanswered=unanswered,
    )


@admin_bp.route("/faqs")
@login_required
def faq_list():
    faqs = FAQModel.get_all(active_only=False)
    return render_template("admin/faqs.html", faqs=faqs)


@admin_bp.route("/faqs/add", methods=["POST"])
@login_required
def faq_add():
    question = request.form.get("question", "").strip()
    answer = request.form.get("answer", "").strip()
    category = request.form.get("category", "General").strip() or "General"
    keywords = request.form.get("keywords", "").strip()

    if question and answer:
        FAQModel.create(question, answer, category, keywords)
        refresh_nlp_engine()
        flash("FAQ added successfully.", "success")
    else:
        flash("Question and answer are required.", "error")

    return redirect(url_for("admin.faq_list"))


@admin_bp.route("/faqs/edit/<int:faq_id>", methods=["POST"])
@login_required
def faq_edit(faq_id):
    question = request.form.get("question", "").strip()
    answer = request.form.get("answer", "").strip()
    category = request.form.get("category", "General").strip() or "General"
    keywords = request.form.get("keywords", "").strip()
    is_active = 1 if request.form.get("is_active") == "on" else 0

    FAQModel.update(faq_id, question, answer, category, keywords, is_active)
    refresh_nlp_engine()
    flash("FAQ updated successfully.", "success")
    return redirect(url_for("admin.faq_list"))


@admin_bp.route("/faqs/delete/<int:faq_id>", methods=["POST"])
@login_required
def faq_delete(faq_id):
    FAQModel.delete(faq_id)
    refresh_nlp_engine()
    flash("FAQ deleted.", "success")
    return redirect(url_for("admin.faq_list"))


@admin_bp.route("/faqs/toggle/<int:faq_id>", methods=["POST"])
@login_required
def faq_toggle(faq_id):
    FAQModel.toggle_active(faq_id)
    refresh_nlp_engine()
    return jsonify({"success": True})
