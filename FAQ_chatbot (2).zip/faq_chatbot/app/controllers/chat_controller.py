"""
chat_controller.py
---------------------------------------------------------
Controller (C in MVC) for end-user chat functionality.
Exposes a Blueprint with routes for:
  - Rendering the chat UI
  - Handling chat messages (NLP matching)
  - Returning chat history for a session
---------------------------------------------------------
"""

import uuid
from flask import Blueprint, render_template, request, jsonify, session

from app.models.faq_model import FAQModel
from app.models.chat_model import ChatModel
from app.models.nlp_engine import matcher

chat_bp = Blueprint("chat", __name__)


def ensure_session_id():
    """Assigns a unique session id per browser session for chat history tracking."""
    if "session_id" not in session:
        session["session_id"] = str(uuid.uuid4())
    return session["session_id"]


@chat_bp.route("/")
def index():
    """Renders the main chatbot interface."""
    ensure_session_id()
    return render_template("index.html")


@chat_bp.route("/api/chat", methods=["POST"])
def chat():
    """
    Main chatbot endpoint.
    Expects JSON: { "message": "<user question>" }
    Returns JSON: { "answer": "...", "confidence": 0.0-1.0, "understood": bool }
    """
    data = request.get_json(silent=True) or {}
    user_message = (data.get("message") or "").strip()
    session_id = ensure_session_id()

    if not user_message:
        return jsonify({"error": "Empty message"}), 400

    result = matcher.find_best_match(user_message)

    matched_faq_id = result["faq"]["id"] if result["faq"] else None

    # Log interaction for chat history + analytics
    ChatModel.log_interaction(
        session_id=session_id,
        user_query=user_message,
        matched_faq_id=matched_faq_id,
        matched_answer=result["answer"],
        confidence_score=result["confidence"],
        was_understood=result["understood"],
    )

    if not result["understood"]:
        ChatModel.log_unanswered(user_message, result["confidence"])

    return jsonify({
        "answer": result["answer"],
        "confidence": result["confidence"],
        "understood": result["understood"],
        "category": result["faq"]["category"] if result["faq"] else None,
    })


@chat_bp.route("/api/history", methods=["GET"])
def history():
    """Returns the chat history for the current browser session (for Chat History feature)."""
    session_id = ensure_session_id()
    records = ChatModel.get_history_by_session(session_id)
    return jsonify({"history": records})


@chat_bp.route("/api/faqs/list", methods=["GET"])
def list_faqs_for_search():
    """Lightweight endpoint powering the 'Search Functionality' / suggestion list in the UI."""
    faqs = FAQModel.get_all(active_only=True)
    simplified = [{"id": f["id"], "question": f["question"], "category": f["category"]} for f in faqs]
    return jsonify({"faqs": simplified})
