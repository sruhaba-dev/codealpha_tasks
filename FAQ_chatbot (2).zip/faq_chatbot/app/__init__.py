"""
app/__init__.py
---------------------------------------------------------
Flask Application Factory.
Wires together the Model (database/NLP), Controllers
(blueprints), and Views (Jinja templates) following the
MVC architecture.
---------------------------------------------------------
"""

import os
from flask import Flask

from app.models.database import init_db
from app.models.faq_model import FAQModel
from app.models.nlp_engine import matcher


def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.environ.get("FAQ_CHATBOT_SECRET_KEY", "dev-secret-key-change-in-production")

    # ---- Initialize database (creates tables + seed data if needed) ----
    init_db()

    # ---- Load FAQ dataset into the NLP engine (TF-IDF fit) at startup ----
    faqs = FAQModel.get_all(active_only=True)
    matcher.rebuild(faqs)

    # ---- Register Blueprints (Controllers) ----
    from app.controllers.chat_controller import chat_bp
    from app.controllers.admin_controller import admin_bp

    app.register_blueprint(chat_bp)
    app.register_blueprint(admin_bp)

    return app
