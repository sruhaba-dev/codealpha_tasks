"""
chat_model.py
---------------------------------------------------------
Model layer for chat history and unanswered query logging.
---------------------------------------------------------
"""

from app.models.database import get_db_connection


class ChatModel:

    @staticmethod
    def log_interaction(session_id, user_query, matched_faq_id, matched_answer,
                         confidence_score, was_understood):
        conn = get_db_connection()
        conn.execute(
            """INSERT INTO chat_history
               (session_id, user_query, matched_faq_id, matched_answer,
                confidence_score, was_understood)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (session_id, user_query, matched_faq_id, matched_answer,
             confidence_score, 1 if was_understood else 0),
        )
        conn.commit()
        conn.close()

    @staticmethod
    def get_history_by_session(session_id, limit=50):
        conn = get_db_connection()
        rows = conn.execute(
            """SELECT * FROM chat_history
               WHERE session_id = ?
               ORDER BY id ASC LIMIT ?""",
            (session_id, limit),
        ).fetchall()
        conn.close()
        return [dict(row) for row in rows]

    @staticmethod
    def log_unanswered(user_query, best_score):
        conn = get_db_connection()
        conn.execute(
            "INSERT INTO unanswered_queries (user_query, best_score) VALUES (?, ?)",
            (user_query, best_score),
        )
        conn.commit()
        conn.close()

    @staticmethod
    def get_unanswered(limit=50):
        conn = get_db_connection()
        rows = conn.execute(
            "SELECT * FROM unanswered_queries ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        conn.close()
        return [dict(row) for row in rows]

    @staticmethod
    def get_stats():
        """Basic dashboard stats: total chats, understood vs not, avg confidence."""
        conn = get_db_connection()
        total = conn.execute("SELECT COUNT(*) FROM chat_history").fetchone()[0]
        understood = conn.execute(
            "SELECT COUNT(*) FROM chat_history WHERE was_understood = 1"
        ).fetchone()[0]
        avg_conf_row = conn.execute(
            "SELECT AVG(confidence_score) FROM chat_history"
        ).fetchone()[0]
        conn.close()
        avg_conf = round(avg_conf_row, 3) if avg_conf_row else 0
        not_understood = total - understood
        return {
            "total_chats": total,
            "understood": understood,
            "not_understood": not_understood,
            "avg_confidence": avg_conf,
        }
