"""
nlp_engine.py
---------------------------------------------------------
The AI/NLP core of the chatbot.

Pipeline:
  1. Preprocess raw text:
       - Lowercasing
       - Tokenization        (NLTK word_tokenize)
       - Stopword Removal    (NLTK stopwords corpus)
       - Lemmatization       (NLTK WordNetLemmatizer)
  2. Vectorize all FAQ questions + the user query using
     TF-IDF (scikit-learn TfidfVectorizer).
  3. Compute Cosine Similarity between the user query vector
     and every FAQ question vector.
  4. Return the FAQ with the highest similarity score, along
     with the confidence score itself.

This module is intentionally self-contained so it can be
unit-tested or reused outside Flask.
---------------------------------------------------------
"""

import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Ensure required NLTK data is available (no-op if already downloaded).
# nltk.data.find() can raise OSError (not just LookupError) for some
# resources/versions (e.g. "punkt_tab" on newer NLTK releases), so we
# catch broadly here and just let nltk.download() handle the rest —
# download() itself is a safe no-op if the data already exists.
for resource in ["punkt", "punkt_tab", "stopwords", "wordnet", "omw-1.4"]:
    try:
        nltk.data.find(
            f"tokenizers/{resource}" if "punkt" in resource else f"corpora/{resource}"
        )
    except Exception:
        nltk.download(resource, quiet=True)

STOP_WORDS = set(stopwords.words("english"))
LEMMATIZER = WordNetLemmatizer()

# Confidence threshold below which we tell the user we couldn't find an answer.
# Tuned for short FAQ-style questions; adjust in config.py if needed.
CONFIDENCE_THRESHOLD = 0.20


def preprocess_text(text: str) -> str:
    """
    Cleans and normalizes a piece of text:
      - lowercase
      - strip punctuation/special characters
      - tokenize
      - remove stopwords
      - lemmatize each remaining token
    Returns a single cleaned string ready for vectorization.
    """
    if not text:
        return ""

    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)   # remove punctuation/special chars
    text = re.sub(r"\s+", " ", text).strip()

    tokens = word_tokenize(text)

    cleaned_tokens = [
        LEMMATIZER.lemmatize(token)
        for token in tokens
        if token not in STOP_WORDS and len(token) > 1
    ]

    return " ".join(cleaned_tokens)


class FAQMatcher:
    """
    Wraps a TF-IDF vectorizer fitted over the current FAQ dataset.
    Call `rebuild(faqs)` whenever the FAQ list changes (e.g. after
    admin adds/edits/deletes an FAQ) to keep the vector space in sync.
    """

    def __init__(self):
        self.vectorizer = TfidfVectorizer()
        self.faq_vectors = None
        self.faqs = []          # list of dicts: id, question, answer, category, keywords
        self.processed_questions = []

    def rebuild(self, faqs):
        """
        Re-fits the TF-IDF vectorizer on the given list of FAQ dicts.
        Each FAQ's question + keywords are combined and preprocessed
        before fitting, so keyword metadata also contributes to matching.
        """
        self.faqs = faqs
        self.processed_questions = []

        for faq in faqs:
            combined_text = faq["question"]
            if faq.get("keywords"):
                combined_text += " " + faq["keywords"]
            self.processed_questions.append(preprocess_text(combined_text))

        if self.processed_questions:
            self.vectorizer = TfidfVectorizer()
            self.faq_vectors = self.vectorizer.fit_transform(self.processed_questions)
        else:
            self.faq_vectors = None

    def find_best_match(self, user_query: str):
        """
        Returns a dict:
          {
            "faq": <matched faq dict or None>,
            "answer": <answer text or fallback message>,
            "confidence": <float 0-1>,
            "understood": <bool>
          }
        """
        if not self.faqs or self.faq_vectors is None:
            return {
                "faq": None,
                "answer": "Sorry, I could not find a suitable answer.",
                "confidence": 0.0,
                "understood": False,
            }

        processed_query = preprocess_text(user_query)

        if not processed_query:
            return {
                "faq": None,
                "answer": "Sorry, I could not find a suitable answer.",
                "confidence": 0.0,
                "understood": False,
            }

        query_vector = self.vectorizer.transform([processed_query])
        similarity_scores = cosine_similarity(query_vector, self.faq_vectors).flatten()

        best_index = similarity_scores.argmax()
        best_score = float(similarity_scores[best_index])

        if best_score < CONFIDENCE_THRESHOLD:
            return {
                "faq": None,
                "answer": "Sorry, I could not find a suitable answer.",
                "confidence": round(best_score, 3),
                "understood": False,
            }

        matched_faq = self.faqs[best_index]
        return {
            "faq": matched_faq,
            "answer": matched_faq["answer"],
            "confidence": round(best_score, 3),
            "understood": True,
        }


# Singleton instance used across the Flask app.
# Controllers call `matcher.rebuild(...)` after any FAQ data change.
matcher = FAQMatcher()
