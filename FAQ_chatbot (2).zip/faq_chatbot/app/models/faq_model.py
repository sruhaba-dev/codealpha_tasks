"""
faq_model.py
---------------------------------------------------------
Model layer (M in MVC) for FAQ records.
All direct SQL related to FAQs lives here so controllers
never touch raw SQL.
---------------------------------------------------------
"""

from app.models.database import get_db_connection


class FAQModel:

    @staticmethod
    def get_all(active_only=True):
        """Return all FAQs, optionally filtering to active ones only."""
        conn = get_db_connection()
        if active_only:
            rows = conn.execute(
                "SELECT * FROM faqs WHERE is_active = 1 ORDER BY id DESC"
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM faqs ORDER BY id DESC").fetchall()
        conn.close()
        return [dict(row) for row in rows]

    @staticmethod
    def get_by_id(faq_id):
        conn = get_db_connection()
        row = conn.execute("SELECT * FROM faqs WHERE id = ?", (faq_id,)).fetchone()
        conn.close()
        return dict(row) if row else None

    @staticmethod
    def create(question, answer, category="General", keywords=""):
        conn = get_db_connection()
        cursor = conn.execute(
            "INSERT INTO faqs (question, answer, category, keywords) VALUES (?, ?, ?, ?)",
            (question, answer, category, keywords),
        )
        conn.commit()
        new_id = cursor.lastrowid
        conn.close()
        return new_id

    @staticmethod
    def update(faq_id, question, answer, category, keywords, is_active=1):
        conn = get_db_connection()
        conn.execute(
            """UPDATE faqs
               SET question = ?, answer = ?, category = ?, keywords = ?,
                   is_active = ?, updated_at = CURRENT_TIMESTAMP
               WHERE id = ?""",
            (question, answer, category, keywords, is_active, faq_id),
        )
        conn.commit()
        conn.close()

    @staticmethod
    def delete(faq_id):
        conn = get_db_connection()
        # Detach historical chat logs from this FAQ first (keeps chat history
        # intact even after the FAQ itself is removed), then delete the FAQ.
        conn.execute(
            "UPDATE chat_history SET matched_faq_id = NULL WHERE matched_faq_id = ?",
            (faq_id,),
        )
        conn.execute("DELETE FROM faqs WHERE id = ?", (faq_id,))
        conn.commit()
        conn.close()

    @staticmethod
    def toggle_active(faq_id):
        conn = get_db_connection()
        conn.execute(
            "UPDATE faqs SET is_active = 1 - is_active WHERE id = ?", (faq_id,)
        )
        conn.commit()
        conn.close()

    @staticmethod
    def count():
        conn = get_db_connection()
        total = conn.execute("SELECT COUNT(*) FROM faqs").fetchone()[0]
        conn.close()
        return total
