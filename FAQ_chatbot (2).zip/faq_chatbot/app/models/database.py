"""
database.py
---------------------------------------------------------
Handles SQLite database connection, initialization, and
seeding. Designed so the app can be ported to MySQL by
swapping the connector (see README for MySQL instructions).
---------------------------------------------------------
"""

import sqlite3
import os
from werkzeug.security import generate_password_hash

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DB_PATH = os.path.join(BASE_DIR, "database", "faq_chatbot.db")
SCHEMA_PATH = os.path.join(BASE_DIR, "database", "schema.sql")


def get_db_connection():
    """Returns a SQLite connection with row access by column name."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """
    Initializes the database:
    - Creates tables + seed FAQs from schema.sql (only runs the
      INSERTs if the faqs table is currently empty, so re-running
      the app doesn't duplicate seed data).
    - Creates a default admin user (admin / admin123) if none exists.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    with open(SCHEMA_PATH, "r") as f:
        schema_sql = f.read()

    # Split schema into "structure" (tables) vs "seed data" (sample FAQ inserts)
    # using the section markers in schema.sql, rather than filtering line-by-line
    # (which breaks multi-line INSERT statements).
    structure_sql = schema_sql.split("-- Seed Data")[0]
    seed_block = schema_sql.split("-- Seed Data: sample FAQs so the bot works out of the box")[1]
    seed_sql = seed_block.split("-- Default admin")[0]

    cursor.executescript(structure_sql)

    cursor.execute("SELECT COUNT(*) FROM faqs")
    faq_count = cursor.fetchone()[0]

    if faq_count == 0:
        cursor.executescript(seed_sql)
        print("[DB INIT] Seeded sample FAQs.")

    # Create default admin user if not present
    cursor.execute("SELECT COUNT(*) FROM admin_users")
    admin_count = cursor.fetchone()[0]
    if admin_count == 0:
        default_hash = generate_password_hash("admin123")
        cursor.execute(
            "INSERT INTO admin_users (username, password_hash) VALUES (?, ?)",
            ("admin", default_hash),
        )
        print("[DB INIT] Created default admin user -> username: admin / password: admin123")

    conn.commit()
    conn.close()


if __name__ == "__main__":
    init_db()
    print(f"[DB INIT] Database ready at {DB_PATH}")
