"""
run.py
---------------------------------------------------------
Entry point for the FAQ Chatbot Flask application.
Run with:  python run.py
---------------------------------------------------------
"""

from app import create_app

app = create_app()

if __name__ == "__main__":
    # debug=True is for development only - turn off in production
    app.run(debug=True, host="0.0.0.0", port=5000, use_reloader=False)
