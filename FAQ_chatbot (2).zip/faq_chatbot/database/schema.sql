-- =========================================================
-- FAQ Chatbot Database Schema
-- Compatible with SQLite (default) and MySQL (with minor tweaks noted)
-- =========================================================

-- ---------------------------------------------------------
-- Table: faqs
-- Stores the FAQ knowledge base used by the NLP matching engine
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS faqs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,   -- MySQL: INT AUTO_INCREMENT PRIMARY KEY
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    category VARCHAR(100) DEFAULT 'General',
    keywords TEXT,                          -- optional extra keywords to boost matching
    is_active INTEGER DEFAULT 1,            -- MySQL: TINYINT(1) DEFAULT 1
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------
-- Table: chat_history
-- Stores every user query, matched answer, and confidence score
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS chat_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id VARCHAR(100) NOT NULL,
    user_query TEXT NOT NULL,
    matched_faq_id INTEGER,
    matched_answer TEXT,
    confidence_score REAL,
    was_understood INTEGER DEFAULT 1,       -- 0 if "no suitable answer" fallback triggered
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (matched_faq_id) REFERENCES faqs(id) ON DELETE SET NULL
);

-- ---------------------------------------------------------
-- Table: admin_users
-- Simple admin login for the Admin Dashboard
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------
-- Table: unanswered_queries
-- Logs queries the bot could not confidently answer
-- (useful for "Learning from User Queries" future enhancement)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS unanswered_queries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_query TEXT NOT NULL,
    best_score REAL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- =========================================================
-- Seed Data: sample FAQs so the bot works out of the box
-- =========================================================
INSERT INTO faqs (question, answer, category, keywords) VALUES
('What is this chatbot?', 'This is an AI-powered FAQ chatbot that uses NLP techniques like tokenization, lemmatization, and TF-IDF with cosine similarity to understand your question and match it to the most relevant answer.', 'General', 'about chatbot purpose'),
('How do I reset my password?', 'To reset your password, go to the login page and click "Forgot Password". You will receive a reset link on your registered email.', 'Account', 'password reset forgot login'),
('What are your working hours?', 'Our support team is available Monday to Saturday, 9 AM to 6 PM.', 'Support', 'hours timing schedule open'),
('How can I contact customer support?', 'You can contact our support team via email at support@example.com or call our helpline at +92-300-1234567.', 'Support', 'contact email phone help'),
('Do you offer refunds?', 'Yes, we offer a full refund within 7 days of purchase if you are not satisfied with our service.', 'Billing', 'refund money back return'),
('How do I create a new account?', 'Click on "Sign Up" on the homepage, fill in your details, verify your email, and your account will be ready to use.', 'Account', 'register signup create account'),
('Is my data secure?', 'Yes, we use industry-standard encryption and never share your personal data with third parties without consent.', 'Security', 'privacy security data safe'),
('What payment methods do you accept?', 'We accept credit/debit cards, bank transfers, JazzCash, EasyPaisa, and PayPal.', 'Billing', 'payment methods cards jazzcash easypaisa'),
('Can I change my subscription plan?', 'Yes, you can upgrade or downgrade your subscription plan anytime from your account settings.', 'Billing', 'subscription plan upgrade downgrade'),
('How do I delete my account?', 'Go to Account Settings, scroll to the bottom, and click "Delete Account". This action is permanent and cannot be undone.', 'Account', 'delete remove close account');

-- =========================================================
-- Default admin user
-- Username: admin | Password: admin123
-- (Password is hashed in app code using werkzeug.security before insert;
--  this row is inserted programmatically on first run, not via raw SQL,
--  so the hash matches the hashing library used by the app.)
-- =========================================================
