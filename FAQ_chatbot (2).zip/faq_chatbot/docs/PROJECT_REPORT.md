# Project Report: AI-Powered FAQ Chatbot Using Natural Language Processing

## 1. Introduction

Organizations receive large volumes of repetitive customer queries.
This project builds a chatbot that automatically answers such queries
by matching user input against a curated FAQ database using Natural
Language Processing (NLP) and similarity-based information retrieval,
removing the need for a human agent to handle routine questions.

## 2. Problem Statement

Manually answering repetitive questions is time-consuming and does
not scale. A rule-based keyword search is brittle — it fails when
users phrase the same question differently. This project solves that
by using **vector-space text similarity** (TF-IDF + cosine similarity)
instead of exact string/keyword matching, so paraphrased questions
("I forgot my password" vs. "How do I reset my password?") still
resolve to the correct answer.

## 3. Objectives

1. Automatically respond to user questions without human intervention.
2. Intelligently search an FAQ dataset using NLP rather than exact match.
3. Provide a human-like, responsive chat experience.
4. Keep response time low enough for real-time conversation.
5. Allow non-technical staff to maintain the FAQ dataset via an admin panel.

## 4. System Design

### 4.1 High-Level Workflow

1. User types (or speaks) a question into the chat interface.
2. The Flask backend receives the question via the `/api/chat` endpoint.
3. The NLP engine preprocesses the text: lowercasing, tokenization,
   stopword removal, and lemmatization.
4. The cleaned query is vectorized using the same TF-IDF vocabulary
   fitted on the FAQ dataset.
5. Cosine similarity is computed between the query vector and every
   FAQ vector.
6. The highest-scoring FAQ is returned if its score clears the
   confidence threshold; otherwise a fallback message is shown.
7. The interaction (query, matched answer, confidence score) is logged
   to the `chat_history` table for the Chat History feature and for
   admin analytics.

### 4.2 Why TF-IDF + Cosine Similarity (and not just keyword search)

- **TF-IDF** (Term Frequency–Inverse Document Frequency) weights words
  by how distinctive they are to a specific FAQ, down-weighting common
  words that appear in many FAQs (even after stopword removal).
- **Cosine Similarity** measures the angle between the query vector and
  each FAQ vector, which is robust to differences in sentence length —
  a short query and a longer FAQ question can still score highly if
  they share important terms in similar proportion.
- Together they let the system generalize to paraphrased input without
  needing a large training set or external API calls, which keeps the
  system fast, free to run, and fully explainable (the confidence score
  shown to the user is the literal cosine similarity value).

### 4.3 MVC Architecture

| Layer | Responsibility | Location |
|---|---|---|
| Model | Database access, NLP logic | `app/models/` |
| View | HTML templates, styling | `app/templates/`, `app/static/` |
| Controller | Route handling, request/response orchestration | `app/controllers/` |

This separation means the NLP engine (`nlp_engine.py`) can be unit
tested independently of Flask, and the database layer can be swapped
(SQLite → MySQL) without touching controller or view code.

## 5. Database Design

### Entity Overview
- **faqs** — the knowledge base (question, answer, category, keywords, active flag)
- **chat_history** — every user interaction with the matched answer and confidence score
- **admin_users** — admin credentials (hashed passwords via Werkzeug)
- **unanswered_queries** — log of low-confidence queries, feeding the "Learning from User Queries" future enhancement

See `database/schema.sql` for full DDL with inline comments, and the
ER relationships are: `chat_history.matched_faq_id` → `faqs.id`
(nullable, `ON DELETE SET NULL` so historical chat logs survive FAQ
deletion).

## 6. NLP Pipeline Detail

```python
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)      # strip punctuation
    tokens = word_tokenize(text)                   # tokenization
    cleaned = [
        lemmatizer.lemmatize(t)                    # lemmatization
        for t in tokens
        if t not in stopwords and len(t) > 1        # stopword removal
    ]
    return " ".join(cleaned)
```

Lemmatization was chosen over stemming for the final implementation
because it produces real dictionary words (e.g. "running" → "run"
rather than a stemmer's potentially non-word output), which keeps the
matching vocabulary cleaner and easier to debug/inspect in the admin
panel's unanswered-query log.

## 7. Testing Summary

The system was tested end-to-end against a running instance:

| Test | Input | Result |
|---|---|---|
| Paraphrase matching | "I forgot my password, how do I get back in" | Matched password-reset FAQ, confidence 0.548 |
| Paraphrase matching | "can I get my money back" | Matched refund FAQ, confidence 0.500 |
| Out-of-scope rejection | "what is the weather like on mars" | Correctly returned fallback message, confidence 0.0 |
| Live FAQ addition | Added "Urdu support" FAQ via admin panel | Immediately matchable by chatbot at confidence 0.827, no restart needed |
| Deactivation | Toggled FAQ inactive | Chatbot no longer matches it; fell through to next-best FAQ |
| Deletion with history | Deleted an FAQ already referenced in chat_history | FAQ removed; chat history row preserved with reference cleared (no error) |
| Admin auth | Access `/admin/dashboard` without login | Redirected to login page (302) |
| Admin auth | Login with correct credentials | Redirected to dashboard (302 → 200) |

## 8. Limitations

- TF-IDF is a "bag of words" technique with no true semantic
  understanding — it cannot catch synonyms it has never seen in the
  FAQ text itself (e.g. it won't know "open" relates to "hours" unless
  that word appears in the FAQ's question/keywords field). The
  `keywords` field on each FAQ exists specifically to mitigate this:
  admins can add synonyms manually.
- Matching quality depends on having enough FAQs with distinct
  vocabulary; on a very small dataset, sparse vectors can produce
  unexpectedly low scores for valid paraphrases.
- Currently English-only; see Future Enhancements for the multilingual path.

## 9. Conclusion

The project demonstrates a complete, working pipeline from raw user
text to a confidently-matched answer using classical NLP and
information-retrieval techniques, wrapped in a production-shaped Flask
application with proper MVC separation, an admin content-management
panel, and a polished, accessible chat UI with voice and dark-mode
support — suitable as a Final Year Project submission and as a
foundation for a real deployed support bot.
